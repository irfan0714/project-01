<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form id= 'myform'>
		<table>
			<tr>
				<td>
					<select name="opt" multiple="" id="opt">
						<option value="nilai1">option1</option>
						<option value="nilai2">option2</option>
						<option value="nilai3">option3</option>
						<option value="nilai4">option4</option>
						<option value="nilai5">option5</option>
						<option value="nilai6">option6</option>
						<option value="nilai7">option7</option>
					</select>
				</td>
				<td valign="top">
					<div id="pilihan"></div>
				</td>
			</tr>
		</table>
		<button type="submit">Submit</button>
	</form>
	<script src="jquery.js"></script>
	<script type="text/javascript">
		$('#opt').dblclick(function(){
			var val = $(this).val();
			var temp = "<div id='"+val+"'><input type='text' name='nama[]' value='"+val+"' readonly><button type='button'  onclick='cancel(\""+val+"\")'>cancel</button><br></div>";

			$("#opt option:selected").attr('disabled',true);
			$('#pilihan').append(temp);
		});	

		function cancel(val){
			$('#'+val).remove();
			$("#opt option[value='"+val+"']").attr('disabled',false);
		}

		$('#myform').submit(function(e){
			e.preventDefault();

			var data = $('input[name=nama]').val();
			$.ajax({
				url  : "get_form.php",
				type : "POST",
				data : new FormData(this),
                processData:false,
                contentType:false,
                cache:false,
				success: function(res){

				}
			});

		});
	</script>
</body>
</html>