<?php 


	foreach ($_POST['nama'] as $key => $value) {
		echo "SELECT * FROM table WHERE id='".$value."';<br>" ;

		#looping querynya disini
	}
 ?>